const envelope = document.getElementById("envelope");
const envelopeContainer = document.getElementById("envelope-container");
const letterContainer = document.getElementById("letter-container");

envelope.addEventListener("click", () => {
  envelopeContainer.style.display = "none";
  letterContainer.style.display = "flex";
});

function firstYes() {
  document.getElementById("first-buttons").style.display = "none";
  document.getElementById("yes-text").style.display = "block";

  setTimeout(() => {
    document.getElementById("second-question").style.display = "block";
  }, 1200);
}

function showDates() {
  document.getElementById("second-question").style.display = "none";
  document.getElementById("dates").style.display = "block";
}

function finalText(text) {
  document.getElementById("dates").style.display = "none";
  document.getElementById("final-msg").innerText = text;
}
